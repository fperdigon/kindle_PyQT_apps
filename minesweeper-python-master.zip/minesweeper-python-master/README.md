# minesweeper-python
It is a minesweeper game written in Python using PyQt GUI library.

### Language used:
The script is made using python 2.7

### List of libraries used:
* pyqt4

### Testing:
The program runs successfully on Windows 8.
