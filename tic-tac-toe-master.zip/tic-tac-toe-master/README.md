tic-tac-toe
===========

Python PyQt Tic tac toe game NegaMax Algorithm with Alpha Beta Pruning
